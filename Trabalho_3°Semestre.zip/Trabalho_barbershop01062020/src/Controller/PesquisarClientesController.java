/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import Model.DAO.conexaoBD;
import View.PesquisarClientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class PesquisarClientesController {
    private final PesquisarClientes view;

    public PesquisarClientesController(PesquisarClientes view) {
        this.view = view;
    }
    
    public void pesquisaCliente() throws SQLException {
        ArrayList strTabela = new ArrayList<String>();
        Connection conn = new conexaoBD().getConnection();
        String sql = "select id, cliente, telefone from cliente where cliente = ?;";
        String cliente = view.getTxtPesCliente().getText();
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, cliente);
        ResultSet rs = st.executeQuery();
        DefaultTableModel tableModel = (DefaultTableModel) view.getJTableClientes().getModel();
        tableModel.setNumRows(0);
        
        while(rs.next()){
            tableModel.addRow(new String[] {rs.getString("id"), rs.getString("cliente"), rs.getString("telefone")});
        }
    }
}
