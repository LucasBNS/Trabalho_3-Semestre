/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class Cliente{
    
    private int id;
    private String cliente;
    private String telefone;

    public Cliente(int id, String nome, String telefone) {
        this.id = id;
        this.cliente = nome;
        this.telefone = telefone;
    }

    public Cliente(String nome, String telefone) {
        this.cliente = nome;
        this.telefone = telefone;
    }

    public Cliente(String nome) {
        this.cliente = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return cliente;
    }

    public void setNome(String nome) {
        this.cliente = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
    
    @Override
    public String toString() {
        return getNome();
    }
    
}