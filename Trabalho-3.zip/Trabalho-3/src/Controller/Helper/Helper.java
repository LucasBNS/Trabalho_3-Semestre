/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.Helper;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public abstract interface Helper {
    
    public Object obterModelo();
    
    public void limparTela();
    
}
