/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.Helper;

import Model.Usuario;
import View.Login;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class LoginHelper implements Helper {

    private final Login view;

    public LoginHelper(Login view) {
        this.view = view;
    }

    public Usuario obterModelo() {

        String nome = view.getTxtUser().getText();
        String senha = view.getTxtPassword().getText();

        Usuario modelo = new Usuario(0, nome, senha);
        return modelo;

    }

    public void setarModelo(Usuario modelo) {

        String nome = modelo.getNome();
        String senha = modelo.getSenha();

        view.getTxtUser().setText(nome);
        view.getTxtPassword().setText(senha);

    }

    public void limparTela() {

        view.getTxtUser().setText("");
        view.getTxtPassword().setText("");

    }

}
