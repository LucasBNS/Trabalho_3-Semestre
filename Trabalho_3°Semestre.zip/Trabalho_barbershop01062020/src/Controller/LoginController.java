/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.DAO.UsuarioDAO;
import Model.DAO.conexaoBD;
import Model.Usuario;
import View.Login;
import View.MenuPrincipal;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class LoginController {
    private final Login view;

    public LoginController(Login view) {
        this.view = view;
    }
    
    
    public void autenticado() throws SQLException {      
        //Pegando usuario da view.
        String usuario = view.getTxtUser().getText();
        //Pegando senha da view.
        String senha = view.getTxtSenha().getText();
        
        Usuario autenticado = new Usuario(usuario, senha);
        Connection conn = new conexaoBD().getConnection();
        UsuarioDAO usuario_bd = new UsuarioDAO(conn);
        boolean existe = usuario_bd.autenticar(autenticado);
        
        if(existe == true) {
            MenuPrincipal menu = new MenuPrincipal();
            menu.setVisible(true);
            view.dispose();
        } else {
            JOptionPane.showMessageDialog(view, "*** Usuario ou senha inválidos!");
        }
    }
}
