/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.DAO;

import View.Agenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class AgendamentoDAO {
    private final Agenda view;

    public AgendamentoDAO(Agenda view) {
        this.view = view;
    }
    
    /**
     * Insere um agendamento dentro do banco de dados
     */        
    
    public void inserirDadosTabela() throws SQLException {
      Connection conn = new conexaoBD().getConnection();
      String sql = "insert into agendamento(cliente, servico, valor, data, hora, observacao) values(?, ?, ?, ?, ?, ?);";
      String cliente = view.getJcomboBoxCliente1().getSelectedItem().toString();
      String servico = view.getJcomboBoxServico().getSelectedItem().toString();
      String valor = view.getTxtValor().getText();
      String data = view.getTxtData().getText();
      String hora = view.getTxtHora().getText();
      String obs = view.getTxtaObservacao().getText();
      
      PreparedStatement st = conn.prepareStatement(sql);
      st.setString(1, cliente);
      st.setString(2, servico);
      st.setString(3, valor);
      st.setString(4, data);
      st.setString(5, hora);
      st.setString(6, obs);
      st.execute();
      
      String sql_backup = "insert into agendamento_backup(cliente, servico, valor, data, hora, observacao) values(?, ?, ?, ?, ?, ?);";
      PreparedStatement st_backup = conn.prepareStatement(sql_backup);
      st_backup.setString(1, cliente);
      st_backup.setString(2, servico);
      st_backup.setString(3, valor);
      st_backup.setString(4, data);
      st_backup.setString(5, hora);
      st_backup.setString(6, obs);
      st_backup.execute();
    }
}
