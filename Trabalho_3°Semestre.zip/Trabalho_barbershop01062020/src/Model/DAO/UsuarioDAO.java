/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.DAO;

import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class UsuarioDAO {
    private final Connection conn;

    public UsuarioDAO(Connection conn) {
        this.conn = conn;
    }
    
    public boolean autenticar(Usuario usuario) throws SQLException {
       String sql = "select usuario, senha from usuario where usuario = ? and senha = ?;";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, usuario.getUsuario());
        st.setString(2, usuario.getSenha());
        st.execute();
        ResultSet rs = st.getResultSet();
        return rs.next();
    }
}
