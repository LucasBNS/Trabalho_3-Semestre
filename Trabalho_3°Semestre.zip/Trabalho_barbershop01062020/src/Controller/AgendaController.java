/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.DAO.conexaoBD;
import View.Agenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class AgendaController {
    private final Agenda view;

    public AgendaController(Agenda view) {
        this.view = view;
    }
    
    public void preencherClientes() throws SQLException {
        ArrayList strClientes = new ArrayList<String>();
        Connection conn = new conexaoBD().getConnection();
        String sql = "select cliente from cliente;";
        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        DefaultComboBoxModel comboBoxCliente = (DefaultComboBoxModel) view.getJcomboBoxCliente1().getModel();
        
        while(rs.next()){
            do{
                strClientes.add(rs.getString("cliente"));
            } while(rs.next());
            for(Object listaCliente: strClientes){
                comboBoxCliente.addElement(listaCliente);
            }
        }
    }
    
    public void preencherServicos() throws SQLException{
        ArrayList strServicos = new ArrayList<String>();
        Connection conn = new conexaoBD().getConnection();
        String sql = "select servico from servico;";
        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        DefaultComboBoxModel comboBoxServico = (DefaultComboBoxModel) view.getJcomboBoxServico().getModel();
        
        while(rs.next()){
            do{
                strServicos.add(rs.getString("servico"));
            } while(rs.next());
            for(Object listaServico: strServicos){
                comboBoxServico.addElement(listaServico);
            }
        }
    }
    
    public void preencherValor() throws SQLException {
        Connection conn = new conexaoBD().getConnection();
        String sql = "select valor from servico where servico = ?;";
        String servico = view.getJcomboBoxServico().getSelectedItem().toString();
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, servico);
        ResultSet rs = st.executeQuery();
        if(rs.next()){
            view.getTxtValor().setText(rs.getString("valor"));
        }
    }
    
    public void preencherTabela() throws SQLException {
        ArrayList strTabela = new ArrayList<String>();
        Connection conn = new conexaoBD().getConnection();
        String sql = "select cliente, servico, valor, data, hora, observacao from agendamento;";
        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        DefaultTableModel tableModel = (DefaultTableModel) view.getTableAgendamentos().getModel();
        tableModel.setNumRows(0);
        
        while(rs.next()){
            tableModel.addRow(new String[] {rs.getString("cliente"), rs.getString("servico"), rs.getString("valor"), rs.getString("data"), rs.getString("hora"), rs.getString("observacao") });
        }
        
    }
    
    public void deletarAgendamento() throws SQLException {
        Connection conn = new conexaoBD().getConnection();
        String sql = "delete from agendamento where cliente = ? and servico = ? and data = ?;";
        String cliente = view.getTxtDelNome().getText();
        String servico = view.getTxtDelServico().getText();
        String data = view.getTxtDelData().getText();
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, cliente);
        st.setString(2, servico);
        st.setString(3, data);
        st.executeUpdate();
    }
    
    public void limparTela() {
        view.getTxtData().setText("");
        view.getTxtHora().setText("");
        view.getTxtDelData().setText("");
        view.getTxtDelNome().setText("");
        view.getTxtDelServico().setText("");
    }
}
