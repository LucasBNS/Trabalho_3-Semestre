/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.DAO;

import View.Cadastro;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class ClienteDAO {
    private final Cadastro view;

    public ClienteDAO(Cadastro view) {
        this.view = view;
    }
    
    public void cadastrarCliente() throws SQLException {
        try {
            //Configuração de acesso ao jdbc;
            Class.forName("org.postgresql.Driver");
            System.out.println("Conector carregado com sucesso.");
            
            //Acessando banco de dados.
            String jdbcStr = "jdbc:postgresql://localhost:5432/barbershop";
            Connection conn = DriverManager.getConnection(jdbcStr, "postgres", "postgres");
            
            //Pegando campo cliente.
            String cliente = view.getTxtCadClie().getText();
            //Pegando campo telefone.
            String telefone = view.getTxtCadTel().getText();
            
            //Inserindo no banco de dados.
            String sql = "insert into cliente(cliente, telefone) values(?, ?);";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, cliente);
            st.setString(2, telefone);
            st.execute();
            System.out.println("Cadastro realizado com sucesso.");
            conn.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
