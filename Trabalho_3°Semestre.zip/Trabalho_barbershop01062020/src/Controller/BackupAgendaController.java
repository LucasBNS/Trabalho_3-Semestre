/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import Model.DAO.conexaoBD;
import View.BackupAgendamentos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lucas B. Nieto Santos
 */
public class BackupAgendaController {
    private final BackupAgendamentos view;

    public BackupAgendaController(BackupAgendamentos view) {
        this.view = view;
    }
    
    public void preencherTabelaBackup() throws SQLException {
        ArrayList strTabela = new ArrayList();
        Connection conn = new conexaoBD().getConnection();
        String sql = "select id, cliente, servico, valor, data, hora, observacao from agendamento_backup;";
        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        DefaultTableModel modelo = (DefaultTableModel) view.getJTableBackup().getModel();
        
        while(rs.next()) {
            modelo.addRow(new String[] {
                rs.getString("id"), rs.getString("cliente"), rs.getString("servico"),
                rs.getString("valor"), rs.getString("data"), rs.getString("hora"),
                rs.getString("observacao")
            });
        }
    }
}
